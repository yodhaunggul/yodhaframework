<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$data = array(
			'Nama' => 'Yudha',
			'NIM' => '1541180027' ,
			'Kelas' => 'TI-2D',
			'Organisasi' => 'UKM Seni Theatrisic',
			'Jabatan' => 'Ka. Humas',
			'Phone' => '0822-3344-6010', 
			);
		$this -> load -> view('about',$data);
	}

}



  ?>